The main routine get_mgii_hk.pro computes disk-averaged Mg II h & k
profiles for a past date. It also returns corresponding Bremen
composite Magnesium II index and date in various formats.

The input date of get_mgii_hk.pro must be from 1987 November 7 to
yesterday.  To avoid a name conflict between the IDL function
timestamp.pro, implemented in the routine get_time_for_latis.pro, and
the SolarSoft procedure timestamp.pro, run the routines outside
SolarSoft. The function and procedure have different purposes and
cannot be interchanged. If you want to run SolarSoft together with the
routines then find the procedure timestamp.pro in your SolarSoft
installation and rename it temporally.

The package includes the routines and input files:

get_time_for_latis.pro
read_latis_data.pro
get_double_gauss.pro
gauss1.pro

DataTable3WavScl.sav
get_commons.pro

The routines require the IDL version 8.2.2 or higher. The most up to
date version of read_latis_data.pro can be downloaded from:
https://lasp.colorado.edu/lisird/tools

For Copyright see the sections MODIFICATION HISTORY in individual
routines.

