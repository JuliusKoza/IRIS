The routine get_mgii_hk.pro returns disk-averaged Mg II h and k
profiles for a past date. It also returns corresponding Bremen
composite Magnesium II index and date in various formats. The input
date of get_mgii_hk.pro must be from 1987 November 7 to yesterday.

The routine get_mgii_hk_when_at_meridian.pro returns disk-averaged Mg
II h and k profiles for a date when the point with the heliocentric
Cartesian coordinates (x,y) is at meridian. It also returns the
corresponding Bremen composite Magnesium II index and date in various
formats. If the input coordinates are off the solar limb, their radial
projection back to the nearest point on the limb is used and the
corresponding message is printed.

The package includes the routines and input files:

get_mgii_hk.pro
get_mgii_hk_when_at_meridian.pro

jkidl_check_date.pro
jkidl_check_date_range.pro
jkidl_check_time.pro
jkidl_commons.pro
jkidl_double_gauss.pro
jkidl_stop_msg.pro
jkidl_time_at_meridian.pro
jkidl_time_for_latis.pro

read_latis_data.pro
DataTable3WavScl.sav

The routines require the IDL version 8.2.1 or higher. The most up to
date version of read_latis_data.pro can be downloaded from:
https://lasp.colorado.edu/lisird/tools

For Copyright see the sections MODIFICATION HISTORY in individual
routines.

