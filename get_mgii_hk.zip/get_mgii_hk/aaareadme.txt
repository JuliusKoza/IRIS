The routine get_mgii_hk.pro computes disk-averaged Mg II h and k
profiles for a past date. It also returns corresponding Bremen
composite Magnesium II index and date in various formats. The input
date of get_mgii_hk.pro must be from 1987 November 7 to yesterday.

The routine get_mgii_hk_when_at_meridian.pro computes disk-averaged Mg
II h and k profiles for a date when the point with the heliocentric
Cartesian coordinates x,y is at meridian. It also returns the
corresponding Bremen composite Magnesium II index and date in various
formats.

The package includes the routines and input files:

get_time_for_latis.pro
get_time_at_meridian.pro
get_double_gauss.pro
read_latis_data.pro
check_date.pro
check_time.pro
check_date_range.pro
stop_msg.pro

DataTable3WavScl.sav
get_commons.pro

The routines require the IDL version 8.2.1 or higher. The most up to
date version of read_latis_data.pro can be downloaded from:
https://lasp.colorado.edu/lisird/tools

For Copyright see the sections MODIFICATION HISTORY in individual
routines.

